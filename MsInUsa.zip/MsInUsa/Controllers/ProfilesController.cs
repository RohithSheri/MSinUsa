﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MsInUsa.Model;
using System.Data.Entity.Validation;

namespace MsInUsa.Controllers
{
    [UserAuthorize]
    public class ProfilesController : Controller
    {
        string[] papers = new string[] { "None", "Local", "National", "International" };
        string[] term = new string[] { "Fall", "Spring", "Summmer"};
        MsInUsEntities genConnection = new MsInUsEntities();
       
        public ActionResult add()
        {
            if (Session["AddProfile"] != null && Convert.ToBoolean(Session["AddProfile"]) == false)
            {
                FullProfile fullprofiles = new FullProfile();
                initilization(fullprofiles);
                return View(fullprofiles);
            }
            return RedirectToAction("MyProfile", "Profiles");

        }

        [HttpPost]
        public ActionResult add(FullProfile fullprofile)
        {
            using (MsInUsEntities connection = new MsInUsEntities())
            {
                if (Session["UserName"] != null)
                {
                    fullprofile.Id = Convert.ToInt32(Session["UserId"]);
                    if (fullprofile.Toefl == false) fullprofile.Ielts = true;
                    if (fullprofile.Toefl == null) fullprofile.Toefl = false; fullprofile.Ielts = false;
                    connection.FullProfiles.Add(fullprofile);
                    connection.SaveChanges();
                    Session.Remove("AddProfile");
                }
            }
            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public ActionResult edit(FullProfile fullprofile) {
            using (MsInUsEntities connection = new MsInUsEntities())
            {
                if (Session["UserName"] != null)
                {
                    int id  = Convert.ToInt32(Session["UserId"]);
                    FullProfile fp = connection.FullProfiles.Where(m => m.Id == id).FirstOrDefault();
                    connection.FullProfiles.Remove(fp);
                    connection.SaveChanges();
                    if (fullprofile.Toefl == false) fullprofile.Ielts = true;
                    if (fullprofile.Toefl == null) { fullprofile.Toefl = false; fullprofile.Ielts = false; }
                    connection.FullProfiles.Add(fullprofile);
                    connection.SaveChanges();
                }
            }
            return RedirectToAction("MyProfile", "Profiles");
        }

        [HttpGet]
        public ActionResult edit(int? id)
        {
            id = (id == null) ? Convert.ToInt32(Session["UserId"]) : id;
            FullProfile fullprofiles = new FullProfile();
            fullprofiles = genConnection.FullProfiles.Where(m => m.Id == id).FirstOrDefault();
            initilization(fullprofiles);
            return View(fullprofiles);
        }

        
        [ValidateAdd]
        public ActionResult Myprofile()
        {
            MsInUsEntities dtbase = new MsInUsEntities();
            FullProfile fullprofiles = new FullProfile();
            ///initilization(fullprofiles);
            int id = Convert.ToInt32(Session["UserId"]);
            fullprofiles = dtbase.FullProfiles.FirstOrDefault(m => m.Id == id);
           if(dtbase.AdmitsRejects.Any(m=>m.StudentId == id)) fullprofiles.admitrejects = dtbase.AdmitsRejects.Where(m => m.StudentId == id).ToList();
            return View(fullprofiles);
        }

        [ValidateAdd]
        public ActionResult addUniversities(string university,string course, string status)
        {
            if (!string.IsNullOrEmpty(university))
            {
                int id =  Convert.ToInt32(university);
                if (!genConnection.AdmitsRejects.Any(m => (m.UnivId == id && m.CourseName == course)))
                {
                    AdmitsReject adr = new AdmitsReject();
                    adr.CourseName = course;
                    adr.UnivId = id;
                    adr.Status = status;
                    adr.StudentId = Convert.ToInt32(Session["UserId"]);
                    adr.StudentName = Session["UserName"].ToString();
                    adr.UnivName = genConnection.Universities_list.FirstOrDefault(m => m.UnivId ==id).UnivName;
                    if (genConnection.CourseWorks.Any(m => m.Course == course)) adr.CourseId = genConnection.CourseWorks.FirstOrDefault(m => m.Course == course).CourseId;
                    else adr.CourseId = 0;
                    genConnection.AdmitsRejects.Add(adr);
                    genConnection.SaveChanges();
                }
            }
            return RedirectToAction("Myprofile");
        }

        [ValidateAdd]
        public ActionResult editUniversities(string university, string course, string status)
        {
            if (!string.IsNullOrEmpty(university) || !string.IsNullOrEmpty(course) || !string.IsNullOrEmpty(status))
            {
                int id = Convert.ToInt32(university);
                if (genConnection.AdmitsRejects.Any(m => (m.UnivId == id && m.CourseName == course)))
                {
                    AdmitsReject adr = genConnection.AdmitsRejects.Where(m => (m.CourseName == course && m.UnivId == id)).First();
                    adr.Status = status;
                    genConnection.SaveChanges();
                }
            }
            return RedirectToAction("Myprofile");
        }

        [ValidateAdd]
        public ActionResult deleteUniversities(string university, string course)
        {
            if (!string.IsNullOrEmpty(university) && !string.IsNullOrEmpty(course))
            {
                int id = Convert.ToInt32(university);
                if (genConnection.AdmitsRejects.Any(m => (m.UnivId == id && m.CourseName == course)))
                {
                   AdmitsReject adr = genConnection.AdmitsRejects.FirstOrDefault(m => (m.UnivId == id && m.CourseName == course));
                   genConnection.AdmitsRejects.Remove(adr);
                   genConnection.SaveChanges();
                }
            }
            return RedirectToAction("Myprofile");
        }



       public void initilization(FullProfile fullprofile)
        {
           using(MsInUsEntities dtbase = new MsInUsEntities())
            {
            List<SelectListItem> items = new List<SelectListItem>();
            foreach (var c in dtbase.CourseWorks) { items.Add(new SelectListItem() { Value = c.Course, Text = c.Course }); }
            fullprofile.itemslist = items;
            List<SelectListItem> day = new List<SelectListItem>();
            for (int i = 1; i <= 31; i++)
            { day.Add(new SelectListItem() { Text = Convert.ToString(i), Value = Convert.ToString(i), Selected = (DateTime.Today.Day == i) }); }
            fullprofile.listday = day;
            List<SelectListItem> year = new List<SelectListItem>();
            for (int p = DateTime.Today.Year - 2; p < DateTime.Today.Year + 6; p++)
            { year.Add(new SelectListItem() { Text = Convert.ToString(p), Value = Convert.ToString(p), Selected = (DateTime.Today.Year == p) }); }
            fullprofile.listyear = year;
            List<SelectListItem> month = new List<SelectListItem>();
            foreach (var c in System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.MonthGenitiveNames)
            { month.Add(new SelectListItem() { Text = c, Value = c, Selected = (System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(DateTime.Today.Month) == c) }); }
            fullprofile.listMonth = month;
            List<SelectListItem> papersList = new List<SelectListItem>();
            for (int i = 0; i < papers.Length; i++) { papersList.Add(new SelectListItem() { Text = papers[i], Value = papers[i] }); }
            fullprofile.listpapers = papersList;
            List<SelectListItem> termlist = new List<SelectListItem>();
            for (int i = 0; i < term.Length; i++) { termlist.Add(new SelectListItem() { Text = term[i], Value = term[i] }); }
            fullprofile.listterm = termlist;
            }
        }   
    }
}
