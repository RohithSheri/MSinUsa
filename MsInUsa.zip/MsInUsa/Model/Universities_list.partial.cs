﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsInUsa.Model
{
    public partial class Universities_list
    {
       public List<string> universitycourses { get; set; }
    }
}